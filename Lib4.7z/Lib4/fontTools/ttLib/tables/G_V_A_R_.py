from ._g_v_a_r import table__g_v_a_r


class table_G_V_A_R_(table__g_v_a_r):
    gid_size = 3
